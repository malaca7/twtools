import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { ArrowRight, Boxes, ShoppingCart, Trophy, ShieldCheck } from "lucide-react";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Twin Wheels — Plataforma de Gestão GTA RP" },
      {
        name: "description",
        content:
          "Painel interno da família Twin Wheels: controle de estoque, vendas, metas e desempenho dos membros no GTA RP.",
      },
      { property: "og:title", content: "Twin Wheels — Plataforma de Gestão GTA RP" },
      {
        property: "og:description",
        content: "Estoque, movimentações, vendas e rankings da Twin Wheels em um painel premium.",
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  {
    icon: Boxes,
    title: "Estoque auditável",
    text: "Entradas e saídas com saldo anterior, saldo final e estorno — sem apagar histórico.",
  },
  {
    icon: ShoppingCart,
    title: "Vendas integradas",
    text: "Cada venda gera a saída de estoque automaticamente e bloqueia saldo negativo.",
  },
  {
    icon: Trophy,
    title: "Desempenho real",
    text: "Rankings e metas calculados a partir dos registros do sistema, sem edição manual.",
  },
  {
    icon: ShieldCheck,
    title: "Níveis hierárquicos",
    text: "01, 02, Gerente, Motoqueiro, Membro e Novato com permissões aplicadas no servidor.",
  },
];

function Landing() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && session) navigate({ to: "/dashboard", replace: true });
  }, [loading, session, navigate]);

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
        <Brand size="sm" />
        <Button asChild variant="outline" size="sm">
          <Link to="/auth">Entrar</Link>
        </Button>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-24">
        <section className="py-16 sm:py-24">
          <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">
            Plataforma interna · GTA RP
          </p>
          <Brand size="lg" className="mt-4" />
          <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Centralize estoque, movimentações, vendas e desempenho dos membros da família em um
            painel único, rápido e seguro.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button
              asChild
              size="lg"
              className="glow-primary bg-gradient-brand text-primary-foreground hover:opacity-90"
            >
              <Link to="/auth">
                Acessar painel <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <Card key={f.title} className="surface-card">
              <CardContent className="p-5">
                <span className="inline-flex rounded-xl bg-primary/10 p-2.5 text-primary">
                  <f.icon className="h-5 w-5" />
                </span>
                <h2 className="mt-4 text-base font-semibold text-foreground">{f.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
              </CardContent>
            </Card>
          ))}
        </section>
      </main>
    </div>
  );
}
