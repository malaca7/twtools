import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { errorMessage } from "@/lib/format";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Twin Wheels" },
      {
        name: "description",
        content: "Acesse o painel interno da Twin Wheels com seu e-mail e senha de membro.",
      },
      { property: "og:title", content: "Entrar — Twin Wheels" },
      { property: "og:description", content: "Login da plataforma de gestão Twin Wheels." },
    ],
  }),
  component: AuthPage,
});

const loginSchema = z.object({
  email: z.string().trim().email({ message: "Informe um e-mail válido." }),
  password: z.string().min(6, { message: "A senha precisa ter ao menos 6 caracteres." }),
});

const signupSchema = loginSchema.extend({
  nome: z.string().trim().min(2, { message: "Informe seu nome dentro do jogo." }).max(60),
  nickname: z.string().trim().max(30).optional(),
});

function AuthPage() {
  const navigate = useNavigate();
  const { session, loading: authLoading, refresh } = useAuth();
  const [loading, setLoading] = useState(false);
  const [pendingConfirm, setPendingConfirm] = useState(false);

  useEffect(() => {
    if (!authLoading && session) navigate({ to: "/dashboard", replace: true });
  }, [authLoading, session, navigate]);

  const finalizeMembership = async (nome: string, nickname?: string) => {
    const args = nickname ? { _nome: nome, _nickname: nickname } : { _nome: nome };
    const { error } = await supabase.rpc("ensure_membership", args);
    if (error) throw error;
    await refresh();
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const parsed = loginSchema.safeParse({
      email: form.get("email"),
      password: form.get("password"),
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Dados inválidos.");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword(parsed.data);
      if (error) throw error;
      const meta = data.user?.user_metadata as { nome?: string; nickname?: string } | undefined;
      await finalizeMembership(
        meta?.nome || data.user?.email?.split("@")[0] || "Membro",
        meta?.nickname,
      );
      toast.success("Bem-vindo de volta à Twin Wheels.");
      navigate({ to: "/dashboard", replace: true });
    } catch (error) {
      toast.error(errorMessage(error, "E-mail ou senha incorretos. Verifique e tente novamente."));
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const parsed = signupSchema.safeParse({
      email: form.get("email"),
      password: form.get("password"),
      nome: form.get("nome"),
      nickname: (form.get("nickname") as string) || undefined,
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Dados inválidos.");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: parsed.data.email,
        password: parsed.data.password,
        options: {
          emailRedirectTo: window.location.origin,
          data: { nome: parsed.data.nome, nickname: parsed.data.nickname },
        },
      });
      if (error) throw error;
      if (!data.session) {
        setPendingConfirm(true);
        toast.success("Conta criada! Confirme seu e-mail para acessar o painel.");
        return;
      }
      await finalizeMembership(parsed.data.nome, parsed.data.nickname);
      toast.success("Cadastro concluído. Bem-vindo à Twin Wheels.");
      navigate({ to: "/dashboard", replace: true });
    } catch (error) {
      toast.error(errorMessage(error, "Não foi possível criar a conta."));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link to="/">
            <Brand size="md" className="items-center" subtitle="Gestão interna · GTA RP" />
          </Link>
        </div>

        <Card className="surface-card">
          <CardContent className="p-6">
            {pendingConfirm ? (
              <div className="space-y-3 text-center">
                <h1 className="text-lg font-semibold">Confirme seu e-mail</h1>
                <p className="text-sm text-muted-foreground">
                  Enviamos um link de confirmação. Após confirmar, volte aqui e faça login para
                  entrar no painel.
                </p>
                <Button variant="outline" className="w-full" onClick={() => setPendingConfirm(false)}>
                  Voltar ao login
                </Button>
              </div>
            ) : (
              <Tabs defaultValue="login">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login">Entrar</TabsTrigger>
                  <TabsTrigger value="signup">Criar conta</TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="mt-5">
                  <form className="space-y-4" onSubmit={handleLogin}>
                    <div className="space-y-2">
                      <Label htmlFor="login-email">E-mail</Label>
                      <Input id="login-email" name="email" type="email" autoComplete="email" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="login-password">Senha</Label>
                      <Input
                        id="login-password"
                        name="password"
                        type="password"
                        autoComplete="current-password"
                        required
                      />
                    </div>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-gradient-brand text-primary-foreground hover:opacity-90"
                    >
                      {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                      Entrar no painel
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup" className="mt-5">
                  <form className="space-y-4" onSubmit={handleSignup}>
                    <div className="space-y-2">
                      <Label htmlFor="signup-nome">Nome no jogo</Label>
                      <Input id="signup-nome" name="nome" required maxLength={60} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-nickname">Apelido (opcional)</Label>
                      <Input id="signup-nickname" name="nickname" maxLength={30} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">E-mail</Label>
                      <Input id="signup-email" name="email" type="email" autoComplete="email" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Senha</Label>
                      <Input
                        id="signup-password"
                        name="password"
                        type="password"
                        autoComplete="new-password"
                        minLength={6}
                        required
                      />
                      <p className="text-xs text-muted-foreground">Mínimo de 6 caracteres.</p>
                    </div>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-gradient-brand text-primary-foreground hover:opacity-90"
                    >
                      {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                      Criar conta
                    </Button>
                    <p className="text-center text-xs text-muted-foreground">
                      Novos membros entram como <strong>Novato</strong> até um administrador ajustar o
                      nível.
                    </p>
                  </form>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
