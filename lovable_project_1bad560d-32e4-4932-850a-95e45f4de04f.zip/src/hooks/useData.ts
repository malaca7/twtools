import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppLevel } from "@/lib/permissions";

export type Category = {
  id: string;
  nome: string;
  descricao: string | null;
  ativo: boolean;
  created_at: string;
};

export type Product = {
  id: string;
  nome: string;
  descricao: string | null;
  categoria_id: string | null;
  unidade: string;
  estoque_atual: number;
  estoque_minimo: number;
  preco_sugerido: number;
  ativo: boolean;
  created_at: string;
  updated_at: string;
};

export type Movement = {
  id: string;
  product_id: string;
  user_id: string;
  type: "entrada" | "saida";
  quantity: number;
  previous_balance: number;
  resulting_balance: number;
  reason: string | null;
  sale_id: string | null;
  reversal_of: string | null;
  created_at: string;
};

export type Sale = {
  id: string;
  product_id: string;
  seller_id: string;
  buyer_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  payment_method: string;
  notes: string | null;
  status: "concluida" | "estornada";
  created_at: string;
};

export type Goal = {
  id: string;
  user_id: string;
  type: "vendas" | "faturamento" | "quantidade";
  target_value: number;
  period_start: string;
  period_end: string;
  descricao: string | null;
  created_at: string;
};

export type Member = {
  user_id: string;
  nome: string;
  nickname: string | null;
  status: string;
  data_entrada: string;
  nivel: AppLevel | null;
  created_at: string;
};

export type AuditLog = {
  id: string;
  user_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  old_data: unknown;
  new_data: unknown;
  created_at: string;
};

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: async (): Promise<Category[]> => {
      const { data, error } = await supabase.from("categories").select("*").order("nome");
      if (error) throw error;
      return (data ?? []) as Category[];
    },
  });
}

export function useProducts() {
  return useQuery({
    queryKey: ["products"],
    queryFn: async (): Promise<Product[]> => {
      const { data, error } = await supabase.from("products").select("*").order("nome");
      if (error) throw error;
      return (data ?? []) as Product[];
    },
  });
}

export function useMovements() {
  return useQuery({
    queryKey: ["movements"],
    queryFn: async (): Promise<Movement[]> => {
      const { data, error } = await supabase
        .from("stock_movements")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return (data ?? []) as Movement[];
    },
  });
}

export function useSales() {
  return useQuery({
    queryKey: ["sales"],
    queryFn: async (): Promise<Sale[]> => {
      const { data, error } = await supabase
        .from("sales")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return (data ?? []) as Sale[];
    },
  });
}

export function useGoals() {
  return useQuery({
    queryKey: ["goals"],
    queryFn: async (): Promise<Goal[]> => {
      const { data, error } = await supabase
        .from("goals")
        .select("*")
        .order("period_end", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Goal[];
    },
  });
}

export function useMembers() {
  return useQuery({
    queryKey: ["members"],
    queryFn: async (): Promise<Member[]> => {
      const [{ data: profiles, error: pErr }, { data: roles, error: rErr }] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at"),
        supabase.from("user_roles").select("user_id, nivel"),
      ]);
      if (pErr) throw pErr;
      if (rErr) throw rErr;
      const roleMap = new Map((roles ?? []).map((r) => [r.user_id, r.nivel as AppLevel]));
      return (profiles ?? []).map((p) => ({
        user_id: p.user_id,
        nome: p.nome,
        nickname: p.nickname,
        status: p.status,
        data_entrada: p.data_entrada,
        created_at: p.created_at,
        nivel: roleMap.get(p.user_id) ?? null,
      }));
    },
  });
}

export function useAuditLogs(enabled = true) {
  return useQuery({
    enabled,
    queryKey: ["audit_logs"],
    queryFn: async (): Promise<AuditLog[]> => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return (data ?? []) as AuditLog[];
    },
  });
}

export function nameOf(members: Member[] | undefined, userId: string | null | undefined) {
  if (!userId) return "—";
  const m = members?.find((x) => x.user_id === userId);
  return m?.nickname || m?.nome || "Membro";
}

export function productName(products: Product[] | undefined, id: string) {
  return products?.find((p) => p.id === id)?.nome ?? "Produto";
}
