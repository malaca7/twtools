import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { can, type AppLevel, type Permission } from "@/lib/permissions";

export type Profile = {
  id: string;
  user_id: string;
  nome: string;
  nickname: string | null;
  avatar_url: string | null;
  status: string;
  data_entrada: string;
};

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  level: AppLevel | null;
  loading: boolean;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
  hasPermission: (permission: Permission) => boolean;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [level, setLevel] = useState<AppLevel | null>(null);
  const [loading, setLoading] = useState(true);

  const loadMembership = async (userId: string) => {
    const [{ data: prof }, { data: role }] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", userId).maybeSingle(),
      supabase.from("user_roles").select("nivel").eq("user_id", userId).maybeSingle(),
    ]);
    setProfile((prof as Profile | null) ?? null);
    setLevel(((role?.nivel as AppLevel | undefined) ?? null) as AppLevel | null);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user) {
        setTimeout(() => {
          void loadMembership(nextSession.user.id).finally(() => setLoading(false));
        }, 0);
      } else {
        setProfile(null);
        setLevel(null);
        setLoading(false);
      }
    });

    void supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        await loadMembership(data.session.user.id);
      }
      setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      user: session?.user ?? null,
      profile,
      level,
      loading,
      refresh: async () => {
        if (session?.user) await loadMembership(session.user.id);
      },
      signOut: async () => {
        await supabase.auth.signOut();
      },
      hasPermission: (permission: Permission) => can(level, permission),
    }),
    [session, profile, level, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}
